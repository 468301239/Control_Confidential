% read original data
X = load('z+n.txt');
posOfEast = X(:, 1);
posOfNorth = X(:, 2);
GPSHeading = heading_preprocess(X(:, 3));
% GPSHeading = X(:, 3);
GPSSpeed = X(:, 4);
GyroAngularRate = X(:, 5);
Odometer = X(:, 6);

% add gaussian white noise (mean=0, variance=8) 
posOfEastNoisy = posOfEast + randn(length(posOfEast), 1)*8;
posOfNorthNoisy = posOfNorth + randn(length(posOfEast), 1)*8;

% draw curve with and without noise to compare
figure(1)
x = 1:length(posOfEast);
subplot(211);
plot(x, posOfEast-690000, 'g');
hold on;
plot(x, posOfEastNoisy-690000, 'r');
legend('original data', 'noisy data');
ylabel('posOfEast');
subplot(212);
plot(x, posOfNorth-4850000, 'g');
hold on;
plot(x, posOfNorthNoisy-4850000, 'r');
legend('original data', 'noisy data');
ylabel('posOfNorth');

% generate observed data
Z = [posOfNorthNoisy';posOfEastNoisy';GPSHeading';GPSSpeed';...
    GyroAngularRate'];

% draw curve of original data and observed data to compare, similar to
% figure 1
figure(2);
x = 1:length(posOfEast);
subplot(511);
plot(x, posOfNorth-4850000, 'g');
hold on;
plot(x, Z(1,:)-4850000, 'r');
ylabel('posOfNorth');
subplot(512);
plot(x, posOfEast-690000, 'g');
hold on;
plot(x, Z(2,:)-690000, 'r');
ylabel('posOfEast');
subplot(513);
plot(x, GPSHeading, 'g');
hold on;
plot(x, Z(3,:), 'r');
ylabel('GPSHeading');
subplot(514);
plot(x, GPSSpeed, 'g');
hold on;
plot(x, Z(4,:), 'r');
ylabel('GPSSpeed');
subplot(515);
plot(x, GyroAngularRate, 'g');
hold on;
plot(x, Z(5,:), 'r');
ylabel('GyroAngularRate');

% set Q and R matrix
% Q = eye(7) * 1;
% R = eye(5) * 10;
Q = diag([0.2, 0.2, 0.2, 2, 0.2, 0.2, 0.2]);
R = diag([8, 8, 0.01, 0.01, 0.01]);

% kalman filter, using 'transfer matrix generator'
%   X00:[Ny, Ex, psi, v, psi_dot, B, S]
Xk1k1_hat = [posOfNorth(1);posOfEast(1);GPSHeading(1);GPSSpeed(1);...
    GyroAngularRate(1);0.1;0.1];
%   P00:7*7 matrix
Pk1k1 = 0.1*rand(7);

%   kalman main loop
%       X_hat is used to store estimation
X_hat = zeros(7, length(posOfEast));
X_hat(:,1) = Xk1k1_hat;
for idx = 2:length(posOfEast)
    % one step: cal from down to top
    %   cal P(k+1|k):using X(k|k)
    Pk1k = phi(Xk1k1_hat(3)) * Pk1k1 * phi(Xk1k1_hat(3))' + ...
        gamma() * Q * gamma()';
    %   cal K(k+1):using Z(k+1) and P(k+1|k) which is P(k+1|k+1) of last
    %   step
    Kk1 = Pk1k * h(Odometer(idx))' * ((h(Odometer(idx)) * Pk1k * ...
        h(Odometer(idx))' + R) ^ -1);
    %   cal X(k+1|k):using X(k|k)
    Xk1k_hat = phi(Xk1k1_hat(3)) * Xk1k1_hat;
    %   cal X(k+1|k+1):using X(k+1|k) and Z(k+1)
    Xk1k1_hat = Xk1k_hat + Kk1 * (Z(:,idx) - h(Odometer(idx)) * Xk1k_hat);
    X_hat(:,idx) = Xk1k1_hat;
    %   cal P(k+1|k+1)
    Pk1k1 = Pk1k - Kk1 * h(Odometer(idx)) * Pk1k;
end

% draw curve of observed data and filtered data to compare
figure(3);
subplot(211);
x = 1:length(posOfNorthNoisy);
plot(x, posOfNorthNoisy, 'y');
hold on;
plot(x, X_hat(1, :), 'r');
legend('observed data', 'filtered data');
ylabel('posOfNorth');
subplot(212);
x = 1:length(posOfEastNoisy);
plot(x, posOfEastNoisy, 'y');
hold on;
plot(x, X_hat(2, :), 'r');
legend('observed data', 'filtered data');
ylabel('posOfEast');

% draw trajectory of raw, observed and filtered position data
figure(4)
hold on
plot(posOfEast, posOfNorth, 'y');
plot(posOfEastNoisy, posOfNorthNoisy, 'b');
plot(X_hat(2, :), X_hat(1, :), 'r');
ylabel('trajectory');
legend('raw data', 'observed data', 'filtered data');

% draw curve of speed, heading, bias, s,
figure(5)
x = 1:length(posOfNorthNoisy);
subplot(411)
hold on
plot(x, GPSSpeed, 'b');
plot(x, X_hat(4, :), 'r');
ylabel('speed');
subplot(412)
hold on
plot(x, GPSHeading, 'b');
plot(x, X_hat(3, :), 'r');
ylabel('heading');
subplot(413)
hold on
plot(x, X_hat(6, :), 'r');
ylabel('bias');
subplot(414)
hold on
plot(x, X_hat(7, :), 'r');
ylabel('S');

% mean square error cal
observedError = 0;
filteredError = 0;
for idx = 1:length(posOfEast)
    observedError = observedError + (posOfEast(idx)-...
        posOfEastNoisy(idx))^2 + (posOfNorth(idx)-posOfNorthNoisy(idx))^2;
    filteredError = filteredError + (posOfEast(idx)-...
        X_hat(2, idx))^2 + (posOfNorth(idx)-X_hat(1, idx))^2;
end
observedError / length(posOfEast)
filteredError / length(posOfEast)

hold off
% transfer matrix generator
function [PHI] = phi(psi)
    PHI = eye(7);
    % step: 1s
    T = 1;
    PHI(1, 4) = T * cos(psi/180*pi);
    PHI(2, 4) = T * sin(psi/180*pi);
    PHI(3, 5) = T;
end
function [GAMMA] = gamma()
    GAMMA = eye(7);
end
function [H] = h(n)
    H = zeros(5, 7);
    H(1, 1) = 1;
    H(2, 2) = 1;
    H(3, 3) = 1;
    H(4, 7) = n;
    H(5, 5) = 1;
    H(5, 6) = 1;
end

% heading preprocess
function [heading] = heading_preprocess(heading_old)
   bias = 0;
   last = heading_old(1);
   heading = heading_old;
   for idx = 2:length(heading)
       if (heading_old(idx) + bias - last) > 180
           bias = bias - 360;
       end
       if (heading_old(idx) + bias - last) < -180
           bias = bias + 360;
       end
       last = heading_old(idx) + bias;
       heading(idx) = last;
   end
end